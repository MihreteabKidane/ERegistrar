package edu.miu.cs.cs425.studentRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ERegistrarWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
