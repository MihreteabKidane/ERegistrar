package edu.miu.cs.cs425.studentRegistration.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import edu.miu.cs.cs425.studentRegistration.Service.StudentService;
import edu.miu.cs.cs425.studentRegistration.model.Student;

@Controller
@RequestMapping("/")
public class StudentController {

	private StudentService studentService;

	@Autowired
	public StudentController(StudentService theStudentService) {
		this.studentService = theStudentService;

	}

	@GetMapping("/student/test")
	public String showRegisterForm() {

		return "student/test";
	}

	@GetMapping("student/list")
	public String studentList(Model model) {
		List<Student> students = studentService.findAll();
		model.addAttribute("students", students);
		model.addAttribute("studentCount", students.size());
		return "student/list";
	}

	// @GetMapping("student/list")
//	public ModelAndView studentList() {
//		ModelAndView modelAndView = new ModelAndView();
//		List<Student> students = studentService.getStudents();
//		modelAndView.addObject("student", students);
//		modelAndView.addObject("studentCount", students.size());
//		modelAndView.setViewName("student/list");
//		return modelAndView;
//	}

	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model model) {

		// create model attribute to bind form data
		Student student = new Student();
		model.addAttribute("student", student);
		return "student/student-form";
	}

	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("studentId") Long studentId, Model model) {

		// get the student from the service
		Student theStudent = studentService.findById(studentId);

		// set student as a model attribute to pre-populate the form
		model.addAttribute("student", theStudent);

		// send over to our form
		return "student/student-form";
	}

	@PostMapping("/save")
	public String saveStudent(@ModelAttribute("student") @Valid Student theStudent, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "student/student-form";
		} else {
			// save the student
			studentService.save(theStudent);

			// use a redirect to prevent duplicate submissions
			return "redirect:/student/list";
		}
	}

	@GetMapping("/delete")
	public String delete(@RequestParam("studentId") long theId) {

		// delete the student
		studentService.deleteById(theId);

		// redirect to /employees/list
		return "redirect:/student/list";

	}

	@GetMapping("/search")
	public String search(@RequestParam("firstName") String theFirstName, @RequestParam("lastName") String theLastName,
			Model model) {

		// check names, if both are empty then just give list of all students

		if (theFirstName.trim().isEmpty() && theLastName.trim().isEmpty()) {
			return "redirect:/student/list";
		} else {
			// else, search by first name and last name
			List<Student> student = studentService.searchBy(theFirstName, theLastName);

			// add to the spring model
			model.addAttribute("student", student);

			// send to list-student
			return "student/list";
		}

	}

}
