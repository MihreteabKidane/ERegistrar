package edu.miu.cs.cs425.studentRegistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ERegistrarWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ERegistrarWebAppApplication.class, args);
	}

}
