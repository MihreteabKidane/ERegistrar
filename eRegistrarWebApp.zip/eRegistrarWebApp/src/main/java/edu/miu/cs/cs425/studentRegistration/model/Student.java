package edu.miu.cs.cs425.studentRegistration.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "student")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "studentId")
	private Long studentId;

	@NotEmpty(message = "*Student Number is required")
	@Column(name = "student_Number")
	private String studentNumber;

	@NotEmpty(message = "*First Name is required")
	@Column(name = "first_Name")
	private String firstName;

	@Column(name = "middle_Name")
	private String middleName;

	@NotEmpty(message = "*Last Name is required")
	@Column(name = "last_Name")
	private String lastName;

	@Column(name = "course_gpa")
	private Long cgpa;

	@NotNull(message = "*Enrolmmet Date is required")
	@Column(name = "enrollment_Date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate enrollmentDate;

	@NotBlank(message = "*IsInternational is required")
	@Column(name = "is_international")
	private boolean isInternational;

	public Student() {

	}

	public Student(String studentNumber, String firstName, String middleName, String lastName, Long cgpa,
			LocalDate enrollmentDate, boolean isInternational) {
		this.studentNumber = studentNumber;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.cgpa = cgpa;
		this.enrollmentDate = enrollmentDate;
		this.isInternational = isInternational;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getCgpa() {
		return cgpa;
	}

	public void setCgpa(Long cgpa) {
		this.cgpa = cgpa;
	}

	public LocalDate getEnrollmentDate() {
		return enrollmentDate;
	}

	public void setEnrollmentDate(LocalDate enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

	public boolean isInternational() {
		return isInternational;
	}

	public void setInternational(boolean isInternational) {
		this.isInternational = isInternational;
	}

	@Override
	public String toString() {
		return String.format(
				"Student [studentId=%s, studentNumber=%s, firstName=%s, middleName=%s, lastName=%s, cgpa=%s, enrollmentDate=%s, isInternational=%s]",
				studentId, studentNumber, firstName, middleName, lastName, cgpa, enrollmentDate, isInternational);
	}

}
