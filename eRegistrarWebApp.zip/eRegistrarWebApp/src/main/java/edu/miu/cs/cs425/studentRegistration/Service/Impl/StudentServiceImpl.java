package edu.miu.cs.cs425.studentRegistration.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.miu.cs.cs425.studentRegistration.Repository.StudentRepository;
import edu.miu.cs.cs425.studentRegistration.Service.StudentService;
import edu.miu.cs.cs425.studentRegistration.model.Student;

@Service
public class StudentServiceImpl implements StudentService {

	private StudentRepository studentRepository;

	@Autowired
	public StudentServiceImpl(StudentRepository studentRepo) {

		studentRepository = studentRepo;

	}

	@Override
	public List<Student> findAll() {
		return studentRepository.findAllByOrderByLastNameAsc();
	}

	@Override
	public Student findById(long theId) {
		Optional<Student> result = studentRepository.findById((int) theId);

		Student theStudent = null;

		if (result.isPresent()) {
			theStudent = result.get();
		} else {
			// we didn't find the employee
			throw new RuntimeException("Did not find student id - " + theId);
		}

		return theStudent;
	}

	@Override
	public void save(Student theStudent) {
		studentRepository.save(theStudent);
	}

	@Override
	public List<Student> searchBy(String theFirstName, String theLastName) {

		return studentRepository.findByFirstNameContainsAndLastNameContainsAllIgnoreCase(theFirstName, theLastName);
	}

	@Override
	public void deleteById(long theId) {
		studentRepository.deleteById((int) theId);

	}

	public void deleteById(int theId) {
		studentRepository.deleteById(theId);

	}

}
