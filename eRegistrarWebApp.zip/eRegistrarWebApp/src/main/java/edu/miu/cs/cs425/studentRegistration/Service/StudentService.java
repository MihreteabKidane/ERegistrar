package edu.miu.cs.cs425.studentRegistration.Service;

import java.util.List;

import edu.miu.cs.cs425.studentRegistration.model.Student;

public interface StudentService {
	public List<Student> findAll();

	public Student findById(long theId);

	public void save(Student theStudent);

	public void deleteById(long theId);

	public List<Student> searchBy(String theFirstName, String theLastName);

	void deleteById(int theId);

}
